import amd.*;
public class pkgMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PkgAdd x=new PkgAdd(3,4);
		System.out.print(x.add());
		
	}

}