class PkgAdd {
int a,b;

public PkgAdd(int p, int q) {
	
	this.a=p;
	this.b=q;
}

public int add() {
	
	return (a+b);
}
	
	
}
